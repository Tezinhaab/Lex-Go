export interface Exercise {
  id: string
  type: "multiple-choice" | "true-false" | "fill-blank" | "matching" | "case-analysis"
  question: string
  options?: string[]
  correctAnswer: string | string[]
  explanation: string
  xp: number
}

export interface Lesson {
  id: string
  title: string
  description: string
  type: "lesson" | "practice" | "test" | "boss"
  exercises: Exercise[]
  xpReward: number
  isLocked: boolean
  position: { x: number; y: number }
}

export interface Track {
  id: string
  title: string
  description: string
  icon: string
  color: string
  totalLessons: number
  completedLessons: number
  isLocked: boolean
  lessons: Lesson[]
}

export const learningTracks: Track[] = [
  {
    id: "direito-penal",
    title: "Direito Penal",
    description: "Fundamentos do Direito Penal brasileiro",
    icon: "scale",
    color: "from-blue-500 to-blue-600",
    totalLessons: 24,
    completedLessons: 5,
    isLocked: false,
    lessons: [
      {
        id: "dp-1",
        title: "Introdução ao Direito Penal",
        description: "Conceitos básicos e princípios fundamentais",
        type: "lesson",
        xpReward: 50,
        isLocked: false,
        position: { x: 50, y: 10 },
        exercises: [
          {
            id: "dp-1-1",
            type: "multiple-choice",
            question: "Qual é o princípio que estabelece que não há crime sem lei anterior que o defina?",
            options: [
              "Princípio da Legalidade",
              "Princípio da Anterioridade",
              "Princípio da Culpabilidade",
              "Princípio da Proporcionalidade",
            ],
            correctAnswer: "Princípio da Legalidade",
            explanation:
              "O Princípio da Legalidade (nullum crimen, nulla poena sine lege) está previsto no art. 5º, XXXIX da CF/88 e estabelece que não há crime sem lei anterior que o defina, nem pena sem prévia cominação legal.",
            xp: 10,
          },
          {
            id: "dp-1-2",
            type: "true-false",
            question: "A lei penal pode retroagir para beneficiar o réu.",
            options: ["Verdadeiro", "Falso"],
            correctAnswer: "Verdadeiro",
            explanation:
              "Correto! De acordo com o art. 5º, XL da CF/88, a lei penal não retroagirá, salvo para beneficiar o réu. Este é o Princípio da Retroatividade da Lei Penal Benéfica.",
            xp: 10,
          },
          {
            id: "dp-1-3",
            type: "fill-blank",
            question: 'Complete: "Não há crime sem _____ anterior que o defina, nem pena sem prévia _____ legal."',
            correctAnswer: "lei",
            explanation:
              "Esta é a redação do Princípio da Legalidade conforme o art. 5º, XXXIX da Constituição Federal. A resposta completa é: lei e cominação.",
            xp: 15,
          },
        ],
      },
      {
        id: "dp-2",
        title: "Princípios Fundamentais",
        description: "Princípios que regem o Direito Penal",
        type: "lesson",
        xpReward: 50,
        isLocked: false,
        position: { x: 30, y: 25 },
        exercises: [],
      },
      {
        id: "dp-3",
        title: "Prática: Princípios",
        description: "Exercícios sobre princípios do Direito Penal",
        type: "practice",
        xpReward: 75,
        isLocked: false,
        position: { x: 70, y: 25 },
        exercises: [],
      },
      {
        id: "dp-4",
        title: "Teoria do Crime",
        description: "Conceito analítico de crime",
        type: "lesson",
        xpReward: 50,
        isLocked: true,
        position: { x: 50, y: 40 },
        exercises: [],
      },
      {
        id: "dp-5",
        title: "Fato Típico",
        description: "Elementos do fato típico",
        type: "lesson",
        xpReward: 50,
        isLocked: true,
        position: { x: 30, y: 55 },
        exercises: [],
      },
      {
        id: "dp-6",
        title: "Boss: Fundamentos",
        description: "Teste final da unidade",
        type: "boss",
        xpReward: 150,
        isLocked: true,
        position: { x: 50, y: 70 },
        exercises: [],
      },
    ],
  },
  {
    id: "direito-civil",
    title: "Direito Civil",
    description: "Relações jurídicas entre particulares",
    icon: "users",
    color: "from-green-500 to-green-600",
    totalLessons: 32,
    completedLessons: 0,
    isLocked: true,
    lessons: [],
  },
  {
    id: "direito-constitucional",
    title: "Direito Constitucional",
    description: "Fundamentos da Constituição Federal",
    icon: "book-open",
    color: "from-purple-500 to-purple-600",
    totalLessons: 28,
    completedLessons: 0,
    isLocked: true,
    lessons: [],
  },
  {
    id: "direito-administrativo",
    title: "Direito Administrativo",
    description: "Organização e funcionamento da Administração Pública",
    icon: "building",
    color: "from-orange-500 to-orange-600",
    totalLessons: 26,
    completedLessons: 0,
    isLocked: true,
    lessons: [],
  },
]
