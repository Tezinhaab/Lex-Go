export interface NewsArticle {
  id: string
  title: string
  summary: string
  category: "penal" | "civil" | "constitucional" | "trabalhista" | "tributario" | "geral"
  date: Date
  source: string
  imageUrl?: string
}

export const newsArticles: NewsArticle[] = [
  {
    id: "1",
    title: "STF julga constitucionalidade de lei sobre prisão em segunda instância",
    summary:
      "O Supremo Tribunal Federal retomou o julgamento sobre a possibilidade de prisão após condenação em segunda instância. A decisão pode impactar milhares de processos em todo o país.",
    category: "constitucional",
    date: new Date("2025-01-28"),
    source: "STF",
    imageUrl: "/supreme-court-building.png",
  },
  {
    id: "2",
    title: "Nova lei trabalhista entra em vigor neste mês",
    summary:
      "Mudanças nas regras de home office e jornada de trabalho passam a valer a partir desta semana. Empresas têm prazo de 90 dias para se adequar às novas normas.",
    category: "trabalhista",
    date: new Date("2025-01-27"),
    source: "Congresso Nacional",
    imageUrl: "/office-work-legal.jpg",
  },
  {
    id: "3",
    title: "STJ define tese sobre responsabilidade civil em acidentes de trânsito",
    summary:
      "Superior Tribunal de Justiça estabelece novos parâmetros para indenização em casos de acidentes envolvendo veículos automotores.",
    category: "civil",
    date: new Date("2025-01-26"),
    source: "STJ",
    imageUrl: "/traffic-accident-legal.jpg",
  },
  {
    id: "4",
    title: "Reforma tributária: principais mudanças aprovadas",
    summary:
      "Câmara dos Deputados aprova texto final da reforma tributária. Mudanças no IVA e simplificação de impostos são destaques da proposta.",
    category: "tributario",
    date: new Date("2025-01-25"),
    source: "Câmara dos Deputados",
    imageUrl: "/tax-reform-legal.jpg",
  },
  {
    id: "5",
    title: "Novo entendimento sobre legítima defesa em casos de violência doméstica",
    summary:
      "Tribunais superiores consolidam jurisprudência sobre aplicação da legítima defesa em contextos de violência doméstica continuada.",
    category: "penal",
    date: new Date("2025-01-24"),
    source: "CNJ",
    imageUrl: "/justice-gavel.jpg",
  },
  {
    id: "6",
    title: "LGPD: novas diretrizes para proteção de dados pessoais",
    summary:
      "ANPD publica guia atualizado sobre tratamento de dados pessoais sensíveis. Empresas devem revisar políticas de privacidade.",
    category: "geral",
    date: new Date("2025-01-23"),
    source: "ANPD",
    imageUrl: "/data-privacy-legal.jpg",
  },
]
