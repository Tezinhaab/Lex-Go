export interface CommunityPost {
  id: string
  author: {
    name: string
    avatar: string
    title: string
    verified: boolean
  }
  content: string
  hashtags: string[]
  likes: number
  comments: number
  shares: number
  timestamp: Date
  liked?: boolean
}

export const communityPosts: CommunityPost[] = [
  {
    id: "1",
    author: {
      name: "Dra. Ana Paula Silva",
      avatar: "AS",
      title: "Advogada Criminalista",
      verified: true,
    },
    content:
      "Acabei de estudar sobre o princípio da presunção de inocência. É impressionante como esse pilar do Direito Penal protege os direitos fundamentais! 📚⚖️",
    hashtags: ["DireitoPenal", "EstudandoDireito", "LexGO"],
    likes: 42,
    comments: 8,
    shares: 3,
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
  },
  {
    id: "2",
    author: {
      name: "Carlos Eduardo Santos",
      avatar: "CE",
      title: "Estudante de Direito - 5º período",
      verified: false,
    },
    content:
      "Alguém pode me ajudar com a diferença entre dolo eventual e culpa consciente? Sempre me confundo nesses conceitos! 🤔",
    hashtags: ["DúvidaJurídica", "DireitoPenal", "Estudos"],
    likes: 15,
    comments: 12,
    shares: 1,
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
  },
  {
    id: "3",
    author: {
      name: "Prof. Roberto Mendes",
      avatar: "RM",
      title: "Professor de Direito Constitucional",
      verified: true,
    },
    content:
      "Dica de ouro para quem está estudando para a OAB: revisem os direitos fundamentais TODOS OS DIAS. Eles aparecem em praticamente todas as provas! 🎯",
    hashtags: ["OAB", "DicasDeEstudo", "DireitoConstitucional"],
    likes: 128,
    comments: 23,
    shares: 45,
    timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000),
  },
  {
    id: "4",
    author: {
      name: "Mariana Costa",
      avatar: "MC",
      title: "Advogada Trabalhista",
      verified: true,
    },
    content:
      "Importante: STF decidiu hoje sobre a constitucionalidade da reforma trabalhista. Quem está acompanhando? Vamos debater! 💼⚖️",
    hashtags: ["STF", "DireitoDoTrabalho", "Jurisprudência"],
    likes: 89,
    comments: 34,
    shares: 18,
    timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000),
  },
  {
    id: "5",
    author: {
      name: "Lucas Ferreira",
      avatar: "LF",
      title: "Estudante de Direito - 3º período",
      verified: false,
    },
    content:
      "Consegui 95% de acerto na trilha de Direito Penal do Lex GO! 🎉 O Juriton está me ajudando muito nos estudos. Quem mais está usando?",
    hashtags: ["LexGO", "Conquista", "EstudandoDireito"],
    likes: 67,
    comments: 19,
    shares: 8,
    timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000),
  },
  {
    id: "6",
    author: {
      name: "Dra. Juliana Oliveira",
      avatar: "JO",
      title: "Defensora Pública",
      verified: true,
    },
    content:
      "A advocacia vai muito além dos tribunais. É sobre defender direitos, promover justiça e transformar vidas. Orgulho de fazer parte dessa profissão! 💙⚖️",
    hashtags: ["Advocacia", "Justiça", "DefensoriaPública"],
    likes: 203,
    comments: 41,
    shares: 67,
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000),
  },
]
