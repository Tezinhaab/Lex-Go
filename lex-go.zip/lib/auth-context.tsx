"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

interface User {
  id: string
  name: string
  email: string
  level: number
  xp: number
  streak: number
  achievements: string[]
  completedLessons: string[]
  createdAt: string
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  register: (name: string, email: string, password: string) => Promise<boolean>
  logout: () => void
  updateUser: (updates: Partial<User>) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedUser = localStorage.getItem("lexgo_user")
      if (storedUser) {
        try {
          setUser(JSON.parse(storedUser))
        } catch (error) {
          localStorage.removeItem("lexgo_user")
        }
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    if (typeof window === "undefined") return false

    const users = JSON.parse(localStorage.getItem("lexgo_users") || "[]")
    const foundUser = users.find((u: any) => u.email === email && u.password === password)

    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser
      setUser(userWithoutPassword)
      localStorage.setItem("lexgo_user", JSON.stringify(userWithoutPassword))
      return true
    }
    return false
  }

  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    if (typeof window === "undefined") return false

    const users = JSON.parse(localStorage.getItem("lexgo_users") || "[]")

    if (!email.includes("@")) {
      return false
    }

    if (users.find((u: any) => u.email === email)) {
      return false
    }

    const newUser = {
      id: Math.random().toString(36).substr(2, 9),
      name,
      email,
      password,
      level: 1,
      xp: 0,
      streak: 0,
      achievements: [],
      completedLessons: [],
      createdAt: new Date().toISOString(),
    }

    users.push(newUser)
    localStorage.setItem("lexgo_users", JSON.stringify(users))

    const { password: _, ...userWithoutPassword } = newUser
    setUser(userWithoutPassword)
    localStorage.setItem("lexgo_user", JSON.stringify(userWithoutPassword))
    return true
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("lexgo_user")
  }

  const updateUser = (updates: Partial<User>) => {
    if (!user) return
    if (typeof window === "undefined") return

    const updatedUser = { ...user, ...updates }
    setUser(updatedUser)
    localStorage.setItem("lexgo_user", JSON.stringify(updatedUser))

    const users = JSON.parse(localStorage.getItem("lexgo_users") || "[]")
    const userIndex = users.findIndex((u: any) => u.id === user.id)
    if (userIndex !== -1) {
      users[userIndex] = { ...users[userIndex], ...updates }
      localStorage.setItem("lexgo_users", JSON.stringify(users))
    }
  }

  if (isLoading) {
    return null
  }

  return <AuthContext.Provider value={{ user, login, register, logout, updateUser }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
