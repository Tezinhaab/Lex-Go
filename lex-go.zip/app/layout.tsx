import type React from "react"
import type { Metadata } from "next"
import { Poppins } from "next/font/google"
import "./globals.css"
import { AuthProvider } from "@/lib/auth-context"
import Script from "next/script"

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-sans",
})

export const metadata: Metadata = {
  title: "Lex GO - Aprenda Direito de Forma Interativa | Preparação OAB",
  description:
    "Plataforma de ensino jurídico gamificado com IA. Aprenda direito de forma interativa, prepare-se para a OAB e tire dúvidas com o Juriton, seu assistente jurídico inteligente.",
  keywords: [
    "direito",
    "OAB",
    "preparação OAB",
    "ensino jurídico",
    "gamificação",
    "IA jurídica",
    "Juriton",
    "aprender direito",
    "direito penal",
    "direito civil",
    "direito constitucional",
    "direito do trabalho",
    "direito tributário",
    "direito empresarial",
    "curso de direito",
    "faculdade de direito",
  ],
  authors: [{ name: "Lex GO" }],
  creator: "Lex GO",
  publisher: "Lex GO",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://lex-go.vercel.app"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "Lex GO - Direito no Dia a Dia",
    description:
      "Aprenda direito de forma gamificada com IA. Prepare-se para a OAB com trilhas interativas e o assistente Juriton.",
    url: "https://lex-go.vercel.app",
    siteName: "Lex GO",
    images: [
      {
        url: "/logo.png",
        width: 1200,
        height: 630,
        alt: "Lex GO - Direito no Dia a Dia",
      },
    ],
    locale: "pt_BR",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Lex GO - Aprenda Direito de Forma Interativa",
    description: "Plataforma de ensino jurídico gamificado com IA",
    images: ["/logo.png"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: [
      { url: "/icon-192.jpg", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.jpg", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icon-192.jpg", sizes: "192x192", type: "image/png" }],
  },
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Lex GO",
  },
  applicationName: "Lex GO",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <head>
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Lex GO" />
        <meta name="theme-color" content="#0A2342" />

        <Script src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX" strategy="afterInteractive" />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-XXXXXXXXXX');
          `}
        </Script>

        <Script id="structured-data" type="application/ld+json">
          {JSON.stringify({
            "@context": "https://schema.org",
            "@type": "EducationalOrganization",
            name: "Lex GO",
            description: "Plataforma de ensino jurídico gamificado com IA",
            url: "https://lex-go.vercel.app",
            logo: "https://lex-go.vercel.app/logo.png",
            sameAs: [],
            contactPoint: {
              "@type": "ContactPoint",
              contactType: "Customer Service",
              availableLanguage: "Portuguese",
            },
            offers: {
              "@type": "Offer",
              category: "Educational",
            },
          })}
        </Script>

        <Script id="sw-register" strategy="afterInteractive">
          {`
            if ('serviceWorker' in navigator) {
              window.addEventListener('load', function() {
                navigator.serviceWorker.register('/sw.js').then(
                  function(registration) {
                  },
                  function(err) {
                    console.error('[Lex GO] Service Worker registration failed:', err);
                  }
                );
              });
            }
          `}
        </Script>
      </head>
      <body className={`${poppins.variable} font-sans antialiased`}>
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  )
}
