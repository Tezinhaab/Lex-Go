"use client"

import { useAuth } from "@/lib/auth-context"
import { LoginScreen } from "@/components/login-screen"
import { HomeScreen } from "@/components/home-screen"

export default function Home() {
  const { user } = useAuth()

  return user ? <HomeScreen /> : <LoginScreen />
}
