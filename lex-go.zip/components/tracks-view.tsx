"use client"

import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Icons } from "@/components/icons"
import { learningTracks } from "@/lib/learning-data"

interface TracksViewProps {
  onSelectTrack: (trackId: string) => void
}

const iconMap: Record<string, any> = {
  scale: Icons.scale,
  users: Icons.users,
  "book-open": Icons.bookOpen,
  building: Icons.building,
}

export function TracksView({ onSelectTrack }: TracksViewProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Trilhas de Aprendizado</h2>
        <p className="text-muted-foreground">Escolha uma disciplina e comece sua jornada jurídica</p>
      </div>

      <div className="grid gap-4">
        {learningTracks.map((track) => {
          const Icon = iconMap[track.icon] || Icons.scale
          const progress = (track.completedLessons / track.totalLessons) * 100

          return (
            <Card
              key={track.id}
              className={`p-6 transition-all ${
                track.isLocked ? "opacity-60 cursor-not-allowed" : "hover:border-primary cursor-pointer hover:shadow-lg"
              }`}
              onClick={() => !track.isLocked && onSelectTrack(track.id)}
            >
              <div className="flex items-start gap-4">
                <div
                  className={`w-16 h-16 rounded-2xl flex items-center justify-center bg-gradient-to-br ${
                    track.isLocked ? "from-muted to-muted" : track.color
                  }`}
                >
                  {track.isLocked ? (
                    <Icons.lock className="w-8 h-8 text-muted-foreground" />
                  ) : (
                    <Icon className="w-8 h-8 text-white" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-xl font-bold mb-1">{track.title}</h3>
                      <p className="text-sm text-muted-foreground">{track.description}</p>
                    </div>
                    {!track.isLocked && <Icons.chevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0" />}
                  </div>

                  {track.isLocked ? (
                    <Badge variant="secondary" className="mt-2">
                      Bloqueado
                    </Badge>
                  ) : (
                    <div className="space-y-2 mt-4">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">
                          {track.completedLessons} de {track.totalLessons} lições
                        </span>
                        <span className="font-semibold">{Math.round(progress)}%</span>
                      </div>
                      <Progress value={progress} />
                    </div>
                  )}
                </div>
              </div>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
