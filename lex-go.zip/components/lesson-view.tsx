"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Icons } from "@/components/icons"
import { learningTracks, type Exercise } from "@/lib/learning-data"

interface LessonViewProps {
  trackId: string
  lessonId: string
  onBack: () => void
  onComplete: () => void
}

export function LessonView({ trackId, lessonId, onBack, onComplete }: LessonViewProps) {
  const { user, updateUser } = useAuth()
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0)
  const [selectedAnswer, setSelectedAnswer] = useState<string>("")
  const [showResult, setShowResult] = useState(false)
  const [isCorrect, setIsCorrect] = useState(false)
  const [earnedXP, setEarnedXP] = useState(0)
  const [correctAnswers, setCorrectAnswers] = useState(0)

  const track = learningTracks.find((t) => t.id === trackId)
  const lesson = track?.lessons.find((l) => l.id === lessonId)

  if (!track || !lesson || !user) return null

  const currentExercise = lesson.exercises[currentExerciseIndex]
  const progress = ((currentExerciseIndex + 1) / lesson.exercises.length) * 100

  const handleSubmit = () => {
    let correct = false
    if (Array.isArray(currentExercise.correctAnswer)) {
      correct = currentExercise.correctAnswer.includes(selectedAnswer.toLowerCase().trim())
    } else {
      correct = currentExercise.correctAnswer === selectedAnswer
    }

    setIsCorrect(correct)
    setShowResult(true)

    if (correct) {
      setEarnedXP(earnedXP + currentExercise.xp)
      setCorrectAnswers(correctAnswers + 1)
    }
  }

  const handleNext = () => {
    if (currentExerciseIndex < lesson.exercises.length - 1) {
      setCurrentExerciseIndex(currentExerciseIndex + 1)
      setSelectedAnswer("")
      setShowResult(false)
    } else {
      const newCompletedLessons = user.completedLessons.includes(lessonId)
        ? user.completedLessons
        : [...user.completedLessons, lessonId]

      updateUser({
        xp: user.xp + earnedXP,
        completedLessons: newCompletedLessons,
        streak: user.streak + 1,
      })
      onComplete()
    }
  }

  const renderExercise = (exercise: Exercise) => {
    switch (exercise.type) {
      case "multiple-choice":
      case "true-false":
        return (
          <div className="space-y-3">
            {exercise.options?.map((option) => (
              <Card
                key={option}
                className={`p-4 cursor-pointer transition-all ${
                  selectedAnswer === option ? "border-primary bg-primary/5" : "hover:border-primary/50"
                } ${showResult && option === exercise.correctAnswer ? "border-green-500 bg-green-50 dark:bg-green-950" : ""} ${showResult && selectedAnswer === option && !isCorrect ? "border-destructive bg-destructive/5" : ""}`}
                onClick={() => !showResult && setSelectedAnswer(option)}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      selectedAnswer === option ? "border-primary bg-primary" : "border-muted-foreground"
                    }`}
                  >
                    {selectedAnswer === option && <div className="w-3 h-3 rounded-full bg-white" />}
                  </div>
                  <span className="font-medium">{option}</span>
                </div>
              </Card>
            ))}
          </div>
        )

      case "fill-blank":
        return (
          <div className="space-y-4">
            <p className="text-lg leading-relaxed">{exercise.question}</p>
            <input
              type="text"
              className="w-full p-4 border-2 rounded-lg focus:border-primary outline-none"
              placeholder="Digite sua resposta..."
              value={selectedAnswer}
              onChange={(e) => setSelectedAnswer(e.target.value)}
              disabled={showResult}
            />
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <Icons.arrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <Progress value={progress} className="h-3" />
        </div>
        <span className="text-sm font-medium text-muted-foreground">
          {currentExerciseIndex + 1} / {lesson.exercises.length}
        </span>
      </div>

      <Card className="p-8">
        <div className="space-y-6">
          <div>
            <h2 className="text-2xl font-bold mb-2">{currentExercise.question}</h2>
            <p className="text-sm text-muted-foreground">
              {currentExercise.xp} XP •{" "}
              {currentExercise.type === "multiple-choice"
                ? "Múltipla escolha"
                : currentExercise.type === "true-false"
                  ? "Verdadeiro ou Falso"
                  : "Preencha o espaço"}
            </p>
          </div>

          {renderExercise(currentExercise)}

          {showResult && (
            <Card
              className={`p-4 ${isCorrect ? "bg-green-50 dark:bg-green-950 border-green-500" : "bg-destructive/5 border-destructive"}`}
            >
              <div className="flex items-start gap-3">
                {isCorrect ? (
                  <Icons.checkCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                ) : (
                  <Icons.xCircle className="w-6 h-6 text-destructive flex-shrink-0 mt-1" />
                )}
                <div className="flex-1">
                  <h3 className="font-semibold mb-1">{isCorrect ? "Correto!" : "Incorreto"}</h3>
                  <p className="text-sm leading-relaxed">{currentExercise.explanation}</p>
                  {isCorrect && <p className="text-sm font-semibold mt-2 text-secondary">+{currentExercise.xp} XP</p>}
                </div>
              </div>
            </Card>
          )}
        </div>
      </Card>

      <div className="flex justify-end">
        {!showResult ? (
          <Button
            size="lg"
            onClick={handleSubmit}
            disabled={!selectedAnswer}
            className="bg-gradient-to-r from-primary to-primary/90"
          >
            Verificar
          </Button>
        ) : (
          <Button size="lg" onClick={handleNext} className="bg-gradient-to-r from-primary to-primary/90">
            {currentExerciseIndex < lesson.exercises.length - 1 ? "Próxima" : "Concluir"}
          </Button>
        )}
      </div>

      {earnedXP > 0 && (
        <div className="text-center">
          <p className="text-sm text-muted-foreground">
            XP acumulado: <span className="font-bold text-secondary">{earnedXP}</span> • Acertos: {correctAnswers}/
            {lesson.exercises.length}
          </p>
        </div>
      )}
    </div>
  )
}
