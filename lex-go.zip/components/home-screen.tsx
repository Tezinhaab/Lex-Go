"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { TracksView } from "@/components/tracks-view"
import { TrackDetail } from "@/components/track-detail"
import { LessonView } from "@/components/lesson-view"
import { JuritonChat } from "@/components/juriton-chat"
import { NewsFeed } from "@/components/news-feed"
import { AchievementsView } from "@/components/achievements-view"
import { Icons } from "@/components/icons"
import Image from "next/image"
import { CommunityFeed } from "@/components/community-feed"

type View = "home" | "tracks" | "track-detail" | "lesson" | "news" | "juriton" | "achievements" | "community"

export function HomeScreen() {
  const [activeView, setActiveView] = useState<View>("home")
  const [selectedTrackId, setSelectedTrackId] = useState<string>("")
  const [selectedLessonId, setSelectedLessonId] = useState<string>("")
  const { user, logout } = useAuth()

  if (!user) return null

  const xpForNextLevel = user.level * 100
  const xpProgress = user.xp % 100

  const initials = user.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)

  const hour = new Date().getHours()
  const greeting = hour < 12 ? "Bom dia" : hour < 18 ? "Boa tarde" : "Boa noite"

  const handleSelectTrack = (trackId: string) => {
    setSelectedTrackId(trackId)
    setActiveView("track-detail")
  }

  const handleStartLesson = (lessonId: string) => {
    setSelectedLessonId(lessonId)
    setActiveView("lesson")
  }

  const handleBackToTracks = () => {
    setActiveView("tracks")
  }

  const handleBackToTrackDetail = () => {
    setActiveView("track-detail")
  }

  const handleLessonComplete = () => {
    setActiveView("track-detail")
  }

  const renderContent = () => {
    switch (activeView) {
      case "tracks":
        return <TracksView onSelectTrack={handleSelectTrack} />

      case "track-detail":
        return <TrackDetail trackId={selectedTrackId} onBack={handleBackToTracks} onStartLesson={handleStartLesson} />

      case "lesson":
        return (
          <LessonView
            trackId={selectedTrackId}
            lessonId={selectedLessonId}
            onBack={handleBackToTrackDetail}
            onComplete={handleLessonComplete}
          />
        )

      case "news":
        return <NewsFeed />

      case "juriton":
        return <JuritonChat />

      case "achievements":
        return <AchievementsView />

      case "community":
        return <CommunityFeed />

      default:
        return (
          <>
            {/* Welcome Section */}
            <div className="mb-8">
              <h1 className="text-3xl font-bold mb-2">
                {greeting}, {user.name.split(" ")[0]}!
              </h1>
              <p className="text-muted-foreground flex items-center gap-2">
                <Icons.scale className="w-4 h-4 text-secondary" />
                Juriton está orgulhoso de você
              </p>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Icons.trophy className="w-5 h-5 text-secondary" />
                  <span className="text-sm text-muted-foreground">XP Total</span>
                </div>
                <p className="text-2xl font-bold">{user.xp.toLocaleString("pt-BR")}</p>
              </Card>
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Icons.flame className="w-5 h-5 text-secondary" />
                  <span className="text-sm text-muted-foreground">Sequência</span>
                </div>
                <p className="text-2xl font-bold">{user.streak} dias</p>
              </Card>
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Icons.award className="w-5 h-5 text-secondary" />
                  <span className="text-sm text-muted-foreground">Conquistas</span>
                </div>
                <p className="text-2xl font-bold">{user.achievements.length}/100</p>
              </Card>
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Icons.target className="w-5 h-5 text-secondary" />
                  <span className="text-sm text-muted-foreground">Nível</span>
                </div>
                <p className="text-2xl font-bold">{user.level}</p>
              </Card>
            </div>

            {/* Learning Path */}
            <Card className="p-6 mb-8 bg-gradient-to-br from-primary/5 to-secondary/5 border-2">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-xl font-bold mb-1">Direito Penal</h2>
                  <p className="text-sm text-muted-foreground">Seção 2: Princípios Fundamentais</p>
                </div>
                <Badge className="bg-secondary text-secondary-foreground">Em progresso</Badge>
              </div>
              <Progress value={65} className="mb-2" />
              <p className="text-sm text-muted-foreground mb-4">
                65% concluído • {xpProgress} XP até o nível {user.level + 1}
              </p>
              <Button
                className="w-full bg-gradient-to-r from-primary to-primary/90"
                size="lg"
                onClick={() => {
                  setSelectedTrackId("direito-penal")
                  setActiveView("track-detail")
                }}
              >
                Continuar aprendendo
              </Button>
            </Card>

            {/* Quick Access */}
            <div className="grid md:grid-cols-2 gap-4 mb-8">
              <Card className="p-6 hover:border-secondary transition-colors cursor-pointer">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                    <Icons.bookOpen className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">Rumo à OAB</h3>
                    <p className="text-sm text-muted-foreground">Modo intensivo de estudos</p>
                  </div>
                </div>
              </Card>

              <Card
                className="p-6 hover:border-secondary transition-colors cursor-pointer"
                onClick={() => setActiveView("news")}
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-secondary/10 rounded-xl flex items-center justify-center">
                    <Icons.newspaper className="w-6 h-6 text-secondary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">Juriton News</h3>
                    <p className="text-sm text-muted-foreground">Notícias jurídicas atualizadas</p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Learning Tracks Preview */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold">Suas Trilhas</h2>
                <Button variant="ghost" onClick={() => setActiveView("tracks")}>
                  Ver todas
                </Button>
              </div>
              <div className="grid md:grid-cols-3 gap-4">
                <Card
                  className="p-6 hover:border-primary transition-colors cursor-pointer"
                  onClick={() => handleSelectTrack("direito-penal")}
                >
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center mb-4">
                    <Icons.scale className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Direito Penal</h3>
                  <Progress value={65} className="mb-2" />
                  <p className="text-sm text-muted-foreground">Seção 2 de 8</p>
                </Card>

                <Card className="p-6 opacity-60">
                  <div className="w-12 h-12 bg-muted rounded-xl flex items-center justify-center mb-4">
                    <Icons.lock className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold mb-2">Direito Civil</h3>
                  <p className="text-sm text-muted-foreground">Bloqueado - Complete Direito Penal</p>
                </Card>

                <Card className="p-6 opacity-60">
                  <div className="w-12 h-12 bg-muted rounded-xl flex items-center justify-center mb-4">
                    <Icons.lock className="w-6 h-6 text-muted-foreground" />
                  </div>
                  <h3 className="font-semibold mb-2">Direito Constitucional</h3>
                  <p className="text-sm text-muted-foreground">Bloqueado</p>
                </Card>
              </div>
            </div>
          </>
        )
    }
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <header className="border-b bg-card sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <Image
              src="/logo.png"
              alt="Lex GO - Direito no Dia a Dia"
              width={120}
              height={35}
              className="object-contain"
              priority
            />
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-secondary/20 rounded-full">
              <Icons.flame className="w-4 h-4 text-secondary" />
              <span className="font-semibold">{user.streak} dias</span>
            </div>
            <button
              onClick={logout}
              className="w-10 h-10 bg-gradient-to-br from-secondary to-secondary/70 rounded-full flex items-center justify-center font-bold text-secondary-foreground hover:opacity-80 transition-opacity"
              title="Sair"
            >
              {initials}
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">{renderContent()}</main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-card border-t">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-around py-3">
            <button
              onClick={() => setActiveView("home")}
              className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
                activeView === "home" ? "text-primary bg-primary/10" : "text-muted-foreground"
              }`}
            >
              <Icons.home className="w-5 h-5" />
              <span className="text-xs font-medium">Início</span>
            </button>

            <button
              onClick={() => setActiveView("news")}
              className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
                activeView === "news" ? "text-primary bg-primary/10" : "text-muted-foreground"
              }`}
            >
              <Icons.newspaper className="w-5 h-5" />
              <span className="text-xs font-medium">Notícias</span>
            </button>

            <button
              onClick={() => setActiveView("juriton")}
              className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
                activeView === "juriton" ? "text-primary bg-primary/10" : "text-muted-foreground"
              }`}
            >
              <Icons.messageCircle className="w-5 h-5" />
              <span className="text-xs font-medium">Juriton</span>
            </button>

            <button
              onClick={() => setActiveView("achievements")}
              className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
                activeView === "achievements" ? "text-primary bg-primary/10" : "text-muted-foreground"
              }`}
            >
              <Icons.award className="w-5 h-5" />
              <span className="text-xs font-medium">Conquistas</span>
            </button>

            <button
              onClick={() => setActiveView("community")}
              className={`flex flex-col items-center gap-1 px-4 py-2 rounded-lg transition-colors ${
                activeView === "community" ? "text-primary bg-primary/10" : "text-muted-foreground"
              }`}
            >
              <Icons.users className="w-5 h-5" />
              <span className="text-xs font-medium">Comunidade</span>
            </button>
          </div>
        </div>
      </nav>
    </div>
  )
}
