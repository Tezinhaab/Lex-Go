"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Icons } from "@/components/icons"
import Image from "next/image"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
}

const suggestedQuestions = [
  "O que é o princípio da legalidade?",
  "Explique a diferença entre dolo e culpa",
  "Quais são os requisitos da legítima defesa?",
  "O que é prescrição penal?",
]

const simulatedResponses: Record<string, string> = {
  "o que é o princípio da legalidade":
    "O Princípio da Legalidade, também conhecido como 'nullum crimen, nulla poena sine lege', está previsto no art. 5º, XXXIX da Constituição Federal. Ele estabelece que não há crime sem lei anterior que o defina, nem pena sem prévia cominação legal. Isso significa que ninguém pode ser punido por um ato que não estava previsto em lei como crime no momento em que foi praticado. É um dos pilares fundamentais do Direito Penal brasileiro!",
  "explique a diferença entre dolo e culpa":
    "Ótima pergunta! Dolo e culpa são formas de culpabilidade:\n\n🎯 DOLO: É quando a pessoa age com intenção, querendo o resultado ou assumindo o risco de produzi-lo. Exemplo: atirar em alguém querendo matá-la.\n\n⚠️ CULPA: É quando a pessoa age sem intenção, mas por imprudência, negligência ou imperícia. Exemplo: dirigir em alta velocidade e atropelar alguém sem querer.\n\nA principal diferença está na vontade: no dolo há intenção, na culpa não há.",
  default:
    "Essa é uma excelente pergunta jurídica! Como assistente de estudos, posso te ajudar com diversos temas do Direito. Para respostas mais específicas, recomendo consultar as trilhas de aprendizado ou o material de estudo completo. Você também pode reformular sua pergunta de forma mais específica!",
}

export function JuritonChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content:
        "Olá! Eu sou o Juriton, seu assistente jurídico inteligente. Estou aqui para te ajudar a entender melhor o Direito. Pode me fazer qualquer pergunta sobre as matérias que você está estudando!",
      timestamp: new Date(),
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, isTyping])

  const getSimulatedResponse = (question: string): string => {
    const normalizedQuestion = question.toLowerCase().trim()

    for (const [key, response] of Object.entries(simulatedResponses)) {
      if (key !== "default" && normalizedQuestion.includes(key)) {
        return response
      }
    }

    return simulatedResponses.default
  }

  const handleSend = async (text?: string) => {
    const messageText = text || input
    if (!messageText.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: messageText,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsTyping(true)

    setTimeout(() => {
      const response = getSimulatedResponse(messageText)
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response,
        timestamp: new Date(),
      }

      setMessages((prev) => [...prev, assistantMessage])
      setIsTyping(false)
    }, 1500)
  }

  const handleSuggestedQuestion = (question: string) => {
    handleSend(question)
  }

  return (
    <div className="flex flex-col h-[calc(100vh-12rem)]">
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-full overflow-hidden bg-gradient-to-br from-secondary/20 to-secondary/10 flex items-center justify-center">
            <Image src="/juriton.png" alt="Juriton" width={48} height={48} className="object-cover" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Juriton AI</h2>
            <p className="text-sm text-muted-foreground flex items-center gap-1">
              <Icons.sparkles className="w-3 h-3" />
              Seu assistente jurídico inteligente
            </p>
          </div>
        </div>
      </div>

      {messages.length === 1 && (
        <div className="mb-6">
          <p className="text-sm text-muted-foreground mb-3">Perguntas sugeridas:</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            {suggestedQuestions.map((question, index) => (
              <Button
                key={index}
                variant="outline"
                className="justify-start text-left h-auto py-3 px-4 bg-transparent"
                onClick={() => handleSuggestedQuestion(question)}
              >
                {question}
              </Button>
            ))}
          </div>
        </div>
      )}

      <Card className="flex-1 p-4 overflow-y-auto mb-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[80%] rounded-2xl px-4 py-3 ${
                  message.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-foreground border border-border"
                }`}
              >
                {message.role === "assistant" && (
                  <div className="flex items-center gap-2 mb-2">
                    <div className="w-6 h-6 rounded-full overflow-hidden bg-gradient-to-br from-secondary/20 to-secondary/10 flex items-center justify-center">
                      <Image src="/juriton.png" alt="Juriton" width={24} height={24} className="object-cover" />
                    </div>
                    <span className="text-xs font-semibold">Juriton</span>
                  </div>
                )}
                <p className="text-sm leading-relaxed whitespace-pre-line">{message.content}</p>
                <p className="text-xs opacity-70 mt-2">
                  {message.timestamp.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex justify-start">
              <div className="max-w-[80%] rounded-2xl px-4 py-3 bg-muted border border-border">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-6 h-6 rounded-full overflow-hidden bg-gradient-to-br from-secondary/20 to-secondary/10 flex items-center justify-center">
                    <Image src="/juriton.png" alt="Juriton" width={24} height={24} className="object-cover" />
                  </div>
                  <span className="text-xs font-semibold">Juriton</span>
                </div>
                <div className="flex gap-1">
                  <div
                    className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                    style={{ animationDelay: "0ms" }}
                  />
                  <div
                    className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                    style={{ animationDelay: "150ms" }}
                  />
                  <div
                    className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"
                    style={{ animationDelay: "300ms" }}
                  />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </Card>

      <div className="flex gap-2">
        <Input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
          placeholder="Faça uma pergunta jurídica..."
          className="flex-1 h-12"
          disabled={isTyping}
        />
        <Button
          onClick={() => handleSend()}
          disabled={!input.trim() || isTyping}
          size="lg"
          className="bg-gradient-to-r from-primary to-primary/90"
        >
          <Icons.send className="w-5 h-5" />
        </Button>
      </div>
    </div>
  )
}
