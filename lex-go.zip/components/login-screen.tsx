"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card } from "@/components/ui/card"
import { Icons } from "@/components/icons"
import Image from "next/image"

export function LoginScreen() {
  const [isLogin, setIsLogin] = useState(true)
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const { login, register } = useAuth()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      let success = false
      if (isLogin) {
        success = await login(email, password)
        if (!success) {
          setError("E-mail ou senha incorretos")
        }
      } else {
        if (!name.trim()) {
          setError("Por favor, insira seu nome")
          setIsLoading(false)
          return
        }
        success = await register(name, email, password)
        if (!success) {
          setError("Este e-mail já está cadastrado")
        }
      }
    } catch (err) {
      setError("Ocorreu um erro. Tente novamente.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-secondary/10 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-8 items-center">
        {/* Left side - Branding */}
        <div className="hidden lg:flex flex-col gap-8">
          <div className="space-y-4">
            <div className="flex flex-col items-start gap-4">
              <Image
                src="/logo.png"
                alt="Lex GO - Direito no Dia a Dia"
                width={280}
                height={80}
                className="object-contain"
                priority
              />
              <p className="text-xl text-foreground/80 leading-relaxed">
                Aprenda Direito de forma interativa e gamificada com o Juriton, seu assistente jurídico inteligente
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Card className="p-4 border-2 hover:border-secondary transition-colors">
              <Icons.bookOpen className="w-8 h-8 text-secondary mb-2" />
              <h3 className="font-semibold mb-1">Trilhas Jurídicas</h3>
              <p className="text-sm text-muted-foreground">Aprenda por disciplinas</p>
            </Card>
            <Card className="p-4 border-2 hover:border-secondary transition-colors">
              <Icons.award className="w-8 h-8 text-secondary mb-2" />
              <h3 className="font-semibold mb-1">Conquistas</h3>
              <p className="text-sm text-muted-foreground">Mais de 100 badges</p>
            </Card>
            <Card className="p-4 border-2 hover:border-secondary transition-colors">
              <Icons.scale className="w-8 h-8 text-secondary mb-2" />
              <h3 className="font-semibold mb-1">Rumo à OAB</h3>
              <p className="text-sm text-muted-foreground">Prepare-se para o exame</p>
            </Card>
            <Card className="p-4 border-2 hover:border-secondary transition-colors">
              <Icons.users className="w-8 h-8 text-secondary mb-2" />
              <h3 className="font-semibold mb-1">Comunidade</h3>
              <p className="text-sm text-muted-foreground">Conecte-se com outros</p>
            </Card>
          </div>
        </div>

        {/* Right side - Login Form */}
        <Card className="p-8 shadow-2xl border-2">
          <div className="lg:hidden mb-6 text-center">
            <div className="flex flex-col items-center gap-3 mb-4">
              <Image
                src="/logo.png"
                alt="Lex GO - Direito no Dia a Dia"
                width={200}
                height={60}
                className="object-contain"
                priority
              />
              <div className="w-16 h-16 rounded-xl overflow-hidden bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center p-1">
                <Image src="/juriton.png" alt="Juriton" width={64} height={64} className="object-contain" />
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="text-center space-y-2">
              <h2 className="text-2xl font-bold">{isLogin ? "Bem-vindo de volta!" : "Crie sua conta"}</h2>
              <p className="text-muted-foreground">
                {isLogin ? "Entre para continuar sua jornada jurídica" : "Comece sua jornada no mundo do Direito"}
              </p>
            </div>

            {error && (
              <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm">
                {error}
              </div>
            )}

            <div className="space-y-4">
              {!isLogin && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Nome completo</label>
                  <Input
                    type="text"
                    placeholder="Seu nome"
                    className="h-12"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required={!isLogin}
                  />
                </div>
              )}

              <div className="space-y-2">
                <label className="text-sm font-medium">E-mail</label>
                <Input
                  type="email"
                  placeholder="seu@email.com"
                  className="h-12"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Senha</label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  className="h-12"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                />
              </div>

              {isLogin && (
                <div className="flex justify-end">
                  <button type="button" className="text-sm text-secondary hover:underline">
                    Esqueceu a senha?
                  </button>
                </div>
              )}

              <Button
                type="submit"
                className="w-full h-12 text-base font-semibold bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary"
                size="lg"
                disabled={isLoading}
              >
                {isLoading ? "Carregando..." : isLogin ? "Entrar" : "Criar conta"}
              </Button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t"></div>
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">Ou continue com</span>
                </div>
              </div>

              <Button type="button" variant="outline" className="w-full h-12 bg-transparent" size="lg">
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                  <path
                    fill="currentColor"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="currentColor"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                  />
                  <path
                    fill="currentColor"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                  />
                </svg>
                Google
              </Button>
            </div>

            <div className="text-center text-sm">
              <span className="text-muted-foreground">{isLogin ? "Não tem uma conta?" : "Já tem uma conta?"}</span>{" "}
              <button
                type="button"
                onClick={() => {
                  setIsLogin(!isLogin)
                  setError("")
                }}
                className="text-secondary font-semibold hover:underline"
              >
                {isLogin ? "Criar conta" : "Entrar"}
              </button>
            </div>
          </form>
        </Card>
      </div>
    </div>
  )
}
