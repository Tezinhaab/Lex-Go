"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Icons } from "@/components/icons"
import { achievementsData, type Achievement } from "@/lib/achievements-data"

const iconMap: Record<string, any> = {
  "book-open": Icons.bookOpen,
  flame: Icons.flame,
  star: Icons.target,
  target: Icons.target,
  trophy: Icons.trophy,
  "graduation-cap": Icons.bookOpen,
  sunrise: Icons.zap,
  moon: Icons.zap,
  calendar: Icons.calendar,
}

const categoryLabels: Record<Achievement["category"], string> = {
  streak: "Sequência",
  lessons: "Lições",
  xp: "Experiência",
  perfect: "Perfeição",
  special: "Especiais",
}

const categoryColors: Record<Achievement["category"], string> = {
  streak: "from-orange-500 to-red-500",
  lessons: "from-blue-500 to-cyan-500",
  xp: "from-yellow-500 to-amber-500",
  perfect: "from-green-500 to-emerald-500",
  special: "from-purple-500 to-pink-500",
}

export function AchievementsView() {
  const [selectedCategory, setSelectedCategory] = useState<Achievement["category"] | "all">("all")

  const filteredAchievements =
    selectedCategory === "all"
      ? achievementsData
      : achievementsData.filter((achievement) => achievement.category === selectedCategory)

  const unlockedCount = achievementsData.filter((a) => a.unlocked).length
  const totalCount = achievementsData.length

  const categories: Array<Achievement["category"] | "all"> = ["all", "streak", "lessons", "xp", "perfect", "special"]

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-gradient-to-br from-secondary to-secondary/80 rounded-xl flex items-center justify-center">
            <Icons.award className="w-6 h-6 text-secondary-foreground" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Conquistas</h2>
            <p className="text-sm text-muted-foreground">
              {unlockedCount} de {totalCount} desbloqueadas
            </p>
          </div>
        </div>

        <Card className="p-6 mb-6 bg-gradient-to-br from-primary/5 to-secondary/5">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Progresso Total</span>
            <span className="text-sm font-bold">{Math.round((unlockedCount / totalCount) * 100)}%</span>
          </div>
          <Progress value={(unlockedCount / totalCount) * 100} className="h-3" />
        </Card>

        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="whitespace-nowrap"
            >
              {category === "all" ? "Todas" : categoryLabels[category]}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredAchievements.map((achievement) => {
          const Icon = iconMap[achievement.icon] || Icons.award
          const progress = (achievement.progress / achievement.requirement) * 100

          return (
            <Card
              key={achievement.id}
              className={`p-6 ${achievement.unlocked ? "border-2 border-secondary" : "opacity-60"}`}
            >
              <div className="flex items-start gap-4 mb-4">
                <div
                  className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                    achievement.unlocked ? `bg-gradient-to-br ${categoryColors[achievement.category]}` : "bg-muted"
                  }`}
                >
                  {achievement.unlocked ? (
                    <Icon className="w-8 h-8 text-white" />
                  ) : (
                    <Icons.lock className="w-8 h-8 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold mb-1">{achievement.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{achievement.description}</p>
                </div>
              </div>

              {achievement.unlocked ? (
                <div className="flex items-center gap-2">
                  <Badge className="bg-secondary text-secondary-foreground">Desbloqueada</Badge>
                  {achievement.unlockedAt && (
                    <span className="text-xs text-muted-foreground">
                      {achievement.unlockedAt.toLocaleDateString("pt-BR")}
                    </span>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">Progresso</span>
                    <span className="font-semibold">
                      {achievement.progress} / {achievement.requirement}
                    </span>
                  </div>
                  <Progress value={progress} />
                </div>
              )}
            </Card>
          )
        })}
      </div>
    </div>
  )
}
