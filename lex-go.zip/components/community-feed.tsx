"use client"

import { useState } from "react"
import { useAuth } from "@/lib/auth-context"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Icons } from "@/components/icons"
import { communityPosts, type CommunityPost } from "@/lib/community-data"

export function CommunityFeed() {
  const { user } = useAuth()
  const [posts, setPosts] = useState<CommunityPost[]>(communityPosts)
  const [newPostContent, setNewPostContent] = useState("")
  const [isPosting, setIsPosting] = useState(false)

  if (!user) return null

  const userInitials = user.name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)

  const handleLike = (postId: string) => {
    setPosts(
      posts.map((post) => {
        if (post.id === postId) {
          return {
            ...post,
            liked: !post.liked,
            likes: post.liked ? post.likes - 1 : post.likes + 1,
          }
        }
        return post
      }),
    )
  }

  const handleCreatePost = () => {
    if (!newPostContent.trim()) return

    const newPost: CommunityPost = {
      id: Date.now().toString(),
      author: {
        name: user.name,
        avatar: userInitials,
        title: "Estudante de Direito",
        verified: false,
      },
      content: newPostContent,
      hashtags: ["LexGO"],
      likes: 0,
      comments: 0,
      shares: 0,
      timestamp: new Date(),
      liked: false,
    }

    setPosts([newPost, ...posts])
    setNewPostContent("")
    setIsPosting(false)
  }

  const formatTimestamp = (date: Date) => {
    const now = new Date()
    const diffInMs = now.getTime() - date.getTime()
    const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60))

    if (diffInHours < 1) {
      const diffInMinutes = Math.floor(diffInMs / (1000 * 60))
      return `${diffInMinutes}m`
    } else if (diffInHours < 24) {
      return `${diffInHours}h`
    } else {
      const diffInDays = Math.floor(diffInHours / 24)
      return `${diffInDays}d`
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Comunidade Jurídica</h1>
        <p className="text-muted-foreground">Conecte-se com estudantes e profissionais do Direito</p>
      </div>

      {/* Create Post */}
      <Card className="p-4 mb-6">
        {!isPosting ? (
          <button
            onClick={() => setIsPosting(true)}
            className="w-full text-left px-4 py-3 bg-muted rounded-lg text-muted-foreground hover:bg-muted/80 transition-colors"
          >
            O que você está estudando hoje?
          </button>
        ) : (
          <div>
            <div className="flex gap-3 mb-3">
              <div className="w-10 h-10 bg-gradient-to-br from-secondary to-secondary/70 rounded-full flex items-center justify-center font-bold text-secondary-foreground flex-shrink-0">
                {userInitials}
              </div>
              <textarea
                value={newPostContent}
                onChange={(e) => setNewPostContent(e.target.value)}
                placeholder="Compartilhe seus estudos, dúvidas ou conquistas..."
                className="flex-1 min-h-[100px] p-3 bg-background border rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                autoFocus
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="ghost" onClick={() => setIsPosting(false)}>
                Cancelar
              </Button>
              <Button onClick={handleCreatePost} disabled={!newPostContent.trim()}>
                <Icons.send className="w-4 h-4 mr-2" />
                Publicar
              </Button>
            </div>
          </div>
        )}
      </Card>

      {/* Posts Feed */}
      <div className="space-y-4">
        {posts.map((post) => (
          <Card key={post.id} className="p-4 hover:border-primary/50 transition-colors">
            {/* Post Header */}
            <div className="flex gap-3 mb-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-primary/70 rounded-full flex items-center justify-center font-bold text-primary-foreground flex-shrink-0">
                {post.author.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold truncate">{post.author.name}</span>
                  {post.author.verified && <Icons.checkCircle className="w-4 h-4 text-primary flex-shrink-0" />}
                  <span className="text-sm text-muted-foreground">·</span>
                  <span className="text-sm text-muted-foreground">{formatTimestamp(post.timestamp)}</span>
                </div>
                <p className="text-sm text-muted-foreground truncate">{post.author.title}</p>
              </div>
            </div>

            {/* Post Content */}
            <p className="mb-3 leading-relaxed">{post.content}</p>

            {/* Hashtags */}
            {post.hashtags.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-3">
                {post.hashtags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="text-xs">
                    #{tag}
                  </Badge>
                ))}
              </div>
            )}

            {/* Post Actions */}
            <div className="flex items-center gap-6 pt-3 border-t">
              <button
                onClick={() => handleLike(post.id)}
                className={`flex items-center gap-2 text-sm transition-colors ${
                  post.liked ? "text-secondary font-semibold" : "text-muted-foreground hover:text-secondary"
                }`}
              >
                <Icons.heart className={`w-5 h-5 ${post.liked ? "fill-secondary" : ""}`} />
                <span>{post.likes}</span>
              </button>

              <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
                <Icons.messageCircle className="w-5 h-5" />
                <span>{post.comments}</span>
              </button>

              <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors">
                <Icons.share className="w-5 h-5" />
                <span>{post.shares}</span>
              </button>
            </div>
          </Card>
        ))}
      </div>

      {/* Load More */}
      <div className="text-center py-8">
        <Button variant="outline" size="lg">
          Carregar mais posts
        </Button>
      </div>
    </div>
  )
}
