"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Icons } from "@/components/icons"
import { learningTracks, type Track } from "@/lib/learning-data"

interface TrackDetailProps {
  trackId: string
  onBack: () => void
  onStartLesson: (lessonId: string) => void
}

export function TrackDetail({ trackId, onBack, onStartLesson }: TrackDetailProps) {
  const track = learningTracks.find((t) => t.id === trackId)

  if (!track) return null

  const getLessonIcon = (lesson: Track["lessons"][0]) => {
    if (lesson.type === "boss") return Icons.crown
    if (lesson.isLocked) return Icons.lock
    return lesson.type === "practice" ? Icons.circle : Icons.checkCircle
  }

  const getLessonColor = (lesson: Track["lessons"][0]) => {
    if (lesson.isLocked) return "bg-muted text-muted-foreground"
    if (lesson.type === "boss") return "bg-gradient-to-br from-secondary to-secondary/80 text-secondary-foreground"
    if (lesson.type === "practice") return "bg-primary/10 text-primary border-2 border-primary"
    return "bg-primary text-primary-foreground"
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={onBack}>
          <Icons.arrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <h2 className="text-2xl font-bold">{track.title}</h2>
          <p className="text-muted-foreground">{track.description}</p>
        </div>
      </div>

      <Card className="p-6 bg-gradient-to-br from-primary/5 to-secondary/5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground mb-1">Progresso</p>
            <p className="text-2xl font-bold">
              {track.completedLessons} / {track.totalLessons} lições
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-muted-foreground mb-1">XP Total</p>
            <p className="text-2xl font-bold text-secondary">
              {track.lessons.reduce((acc, l) => acc + l.xpReward, 0)} XP
            </p>
          </div>
        </div>
      </Card>

      <div className="relative">
        <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-border -translate-x-1/2" />

        <div className="space-y-8 relative">
          {track.lessons.map((lesson, index) => {
            const Icon = getLessonIcon(lesson)
            const isEven = index % 2 === 0

            return (
              <div key={lesson.id} className={`flex items-center gap-4 ${isEven ? "flex-row" : "flex-row-reverse"}`}>
                <div className={`flex-1 ${isEven ? "text-right" : "text-left"}`}>
                  <Card
                    className={`p-4 inline-block max-w-sm ${
                      lesson.isLocked ? "opacity-60" : "hover:border-primary cursor-pointer"
                    }`}
                    onClick={() => !lesson.isLocked && onStartLesson(lesson.id)}
                  >
                    <div className="flex items-center gap-3">
                      {isEven && (
                        <div>
                          <h3 className="font-semibold mb-1">{lesson.title}</h3>
                          <p className="text-sm text-muted-foreground mb-2">{lesson.description}</p>
                          <div className="flex items-center gap-2 justify-end">
                            <Badge variant="secondary" className="text-xs">
                              {lesson.xpReward} XP
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {lesson.type === "lesson" && "Lição"}
                              {lesson.type === "practice" && "Prática"}
                              {lesson.type === "test" && "Teste"}
                              {lesson.type === "boss" && "Boss"}
                            </Badge>
                          </div>
                        </div>
                      )}
                      {!isEven && (
                        <div>
                          <h3 className="font-semibold mb-1">{lesson.title}</h3>
                          <p className="text-sm text-muted-foreground mb-2">{lesson.description}</p>
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary" className="text-xs">
                              {lesson.xpReward} XP
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {lesson.type === "lesson" && "Lição"}
                              {lesson.type === "practice" && "Prática"}
                              {lesson.type === "test" && "Teste"}
                              {lesson.type === "boss" && "Boss"}
                            </Badge>
                          </div>
                        </div>
                      )}
                    </div>
                  </Card>
                </div>

                <div
                  className={`w-16 h-16 rounded-full flex items-center justify-center z-10 ${getLessonColor(lesson)}`}
                >
                  <Icon className="w-8 h-8" />
                </div>

                <div className="flex-1" />
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
