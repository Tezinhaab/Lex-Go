"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Icons } from "@/components/icons"
import { newsArticles, type NewsArticle } from "@/lib/news-data"

const categoryColors: Record<NewsArticle["category"], string> = {
  penal: "bg-red-500/10 text-red-700 dark:text-red-400",
  civil: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
  constitucional: "bg-purple-500/10 text-purple-700 dark:text-purple-400",
  trabalhista: "bg-green-500/10 text-green-700 dark:text-green-400",
  tributario: "bg-orange-500/10 text-orange-700 dark:text-orange-400",
  geral: "bg-gray-500/10 text-gray-700 dark:text-gray-400",
}

const categoryLabels: Record<NewsArticle["category"], string> = {
  penal: "Direito Penal",
  civil: "Direito Civil",
  constitucional: "Direito Constitucional",
  trabalhista: "Direito Trabalhista",
  tributario: "Direito Tributário",
  geral: "Geral",
}

export function NewsFeed() {
  const [selectedCategory, setSelectedCategory] = useState<NewsArticle["category"] | "all">("all")

  const filteredArticles =
    selectedCategory === "all" ? newsArticles : newsArticles.filter((article) => article.category === selectedCategory)

  const categories: Array<NewsArticle["category"] | "all"> = [
    "all",
    "penal",
    "civil",
    "constitucional",
    "trabalhista",
    "tributario",
    "geral",
  ]

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-gradient-to-br from-secondary to-secondary/80 rounded-xl flex items-center justify-center">
            <Icons.newspaper className="w-6 h-6 text-secondary-foreground" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Juriton News</h2>
            <p className="text-sm text-muted-foreground">Notícias jurídicas atualizadas</p>
          </div>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2">
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category)}
              className="whitespace-nowrap"
            >
              {category === "all" ? "Todas" : categoryLabels[category]}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid gap-4">
        {filteredArticles.map((article) => (
          <Card key={article.id} className="overflow-hidden hover:border-primary transition-colors">
            <div className="md:flex">
              {article.imageUrl && (
                <div className="md:w-1/3">
                  <img
                    src={article.imageUrl || "/placeholder.svg"}
                    alt={article.title}
                    className="w-full h-48 md:h-full object-cover"
                  />
                </div>
              )}
              <div className="p-6 flex-1">
                <div className="flex items-start justify-between gap-4 mb-3">
                  <Badge className={categoryColors[article.category]}>{categoryLabels[article.category]}</Badge>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Icons.calendar className="w-3 h-3" />
                    {article.date.toLocaleDateString("pt-BR")}
                  </div>
                </div>

                <h3 className="text-xl font-bold mb-2 leading-tight">{article.title}</h3>
                <p className="text-muted-foreground mb-4 leading-relaxed">{article.summary}</p>

                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Fonte: {article.source}</span>
                  <Button variant="ghost" size="sm" className="gap-2">
                    Ler mais
                    <Icons.externalLink className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
