const { app, BrowserWindow, Menu } = require("electron")
const path = require("path")
const isDev = process.env.NODE_ENV === "development"

let mainWindow

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 768,
    icon: path.join(__dirname, "../public/icon.jpg"),
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      enableRemoteModule: false,
      preload: path.join(__dirname, "preload.js"),
    },
    backgroundColor: "#0A2342",
    show: false,
    titleBarStyle: "default",
    frame: true,
  })

  // Show window when ready to avoid visual flash
  mainWindow.once("ready-to-show", () => {
    mainWindow.show()
  })

  // Load the app
  if (isDev) {
    mainWindow.loadURL("http://localhost:3000")
    mainWindow.webContents.openDevTools()
  } else {
    mainWindow.loadFile(path.join(__dirname, "../.next/server/app/index.html"))
  }

  // Create application menu
  const template = [
    {
      label: "Arquivo",
      submenu: [
        {
          label: "Sair",
          accelerator: "CmdOrCtrl+Q",
          click: () => {
            app.quit()
          },
        },
      ],
    },
    {
      label: "Editar",
      submenu: [
        { label: "Desfazer", accelerator: "CmdOrCtrl+Z", role: "undo" },
        { label: "Refazer", accelerator: "Shift+CmdOrCtrl+Z", role: "redo" },
        { type: "separator" },
        { label: "Recortar", accelerator: "CmdOrCtrl+X", role: "cut" },
        { label: "Copiar", accelerator: "CmdOrCtrl+C", role: "copy" },
        { label: "Colar", accelerator: "CmdOrCtrl+V", role: "paste" },
        { label: "Selecionar Tudo", accelerator: "CmdOrCtrl+A", role: "selectAll" },
      ],
    },
    {
      label: "Visualizar",
      submenu: [
        { label: "Recarregar", accelerator: "CmdOrCtrl+R", role: "reload" },
        { label: "Forçar Recarregar", accelerator: "CmdOrCtrl+Shift+R", role: "forceReload" },
        { type: "separator" },
        { label: "Aumentar Zoom", accelerator: "CmdOrCtrl+Plus", role: "zoomIn" },
        { label: "Diminuir Zoom", accelerator: "CmdOrCtrl+-", role: "zoomOut" },
        { label: "Zoom Padrão", accelerator: "CmdOrCtrl+0", role: "resetZoom" },
        { type: "separator" },
        { label: "Tela Cheia", accelerator: "F11", role: "togglefullscreen" },
      ],
    },
    {
      label: "Ajuda",
      submenu: [
        {
          label: "Sobre Lex GO",
          click: () => {
            const { dialog } = require("electron")
            dialog.showMessageBox(mainWindow, {
              type: "info",
              title: "Sobre Lex GO",
              message: "Lex GO v1.0.0",
              detail: "Plataforma de ensino jurídico gamificado com IA\n\nDesenvolvido com Next.js e Electron",
              buttons: ["OK"],
            })
          },
        },
      ],
    },
  ]

  const menu = Menu.buildFromTemplate(template)
  Menu.setApplicationMenu(menu)

  mainWindow.on("closed", () => {
    mainWindow = null
  })
}

app.whenReady().then(() => {
  createWindow()

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })
})

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit()
  }
})
